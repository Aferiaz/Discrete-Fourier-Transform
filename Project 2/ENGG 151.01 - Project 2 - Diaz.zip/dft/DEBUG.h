/*
  Andreas Josef C. Diaz
  Marc Jefferson B. Obeles
  Justin Gabriel M. Sy

  ENGG 151.01 - A
  Project 2: Discrete Fourier Transform
*/

#ifndef DEBUG_H_INCLUDED
#define DEBUG_H_INCLUDED

#define DEBUG

#endif // DEBUG_H_INCLUDED
